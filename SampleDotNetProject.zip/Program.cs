using System;

namespace SampleDotNetProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Console.WriteLine("This is a sample .NET Console Application.");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
