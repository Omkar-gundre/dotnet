# Sample .NET Project

This is a simple .NET 6 Console Application.

## How to Run
1. Install .NET 6 SDK
2. Open terminal in project folder
3. Run:
   dotnet restore
   dotnet run
